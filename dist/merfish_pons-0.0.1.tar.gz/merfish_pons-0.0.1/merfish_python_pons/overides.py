from collections import defaultdict

overide = defaultdict(dict)
overide["MsBrain_Eg3_VS6_JH_V6_05-01-2021"]["region_1"] = {"img_width": 58115,
                                                           "img_height": 84430}

overide["MsBrain_EG4_VS6library_V6_LH_04-14-21"]["region_1"] = {"img_width": 84388,
                                                                "img_height": 60002}

