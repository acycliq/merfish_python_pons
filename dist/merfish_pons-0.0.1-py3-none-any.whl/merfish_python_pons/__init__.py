from ._version import __version__
from .main import app